﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ADETQ3_Nathaniel__Arcileta.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View("info");
        }

        public IActionResult Abt()
        {
            ViewData["Message"] = "Arcileta, Nathaniel V.";
            return View();
        }
        public IActionResult Error()
        {
            return View();
        }
    }
}
